DHS PARTNER — UPDATED ANDROIDIDE BUILD

UPDATES IN THIS VERSION
1. NEW DHS APP ICON
   - The supplied DHS house/tools icon is now the Android launcher icon.
   - PWA/web 192px and 512px icons are also replaced with the same icon.

2. PARTNER-WISE DATA ISOLATION
   - A partner only loads jobs assigned to the currently signed-in partner UID/email/profile ID.
   - Removed the old global SentToPartner/sentToPartner listener that could make every partner receive the same jobs.
   - Bills and payments remain filtered by partnerId.
   - Completed-job and notification handling now also keeps the partner assignment.
   - Accept/Reject checks that the booking belongs to the logged-in partner before updating it.
   - Completed jobs write partnerId/partnerEmail/workeruid/workeremail so future reads remain isolated.

3. IMPORTANT FIRESTORE SECURITY
   - App-side filtering prevents the UI from showing other partners' records.
   - Real security must ALSO be enforced in Firestore Rules.
   - FIRESTORE_PARTNER_ISOLATION_RULES.txt is included as a reference. Merge its partnerId == request.auth.uid principle into your existing DHS rules; do not blindly replace existing Admin/Customer rules.

ANDROIDIDE BUILD
1. Extract this ZIP.
2. Open the extracted folder as a Gradle project in AndroidIDE.
3. Allow Gradle sync/download when prompted.
4. Build > Assemble Debug.
5. APK: app/build/outputs/apk/debug/app-debug.apk

TEST BEFORE USING LIVE
- Create/login with Partner A and Partner B.
- Admin assigns one booking to Partner A and another to Partner B.
- Partner A must see only A's jobs, completed count, bills and payments.
- Partner B must see only B's jobs, completed count, bills and payments.
- Admin should continue to see the complete company-wide data through the Admin app.

NOTE FOR ADMIN BOOKING ASSIGNMENT
Every job sent to a partner should contain at least one matching assignment field, preferably:
partnerId = partner Firebase Auth UID
partnerEmail = partner email
workeruid = partner Firebase Auth UID
workeremail = partner email

A job with only SentToPartner=true and no partner assignment is intentionally NOT shown to any partner, because showing it would break partner privacy.
